import json
import xmltodict

xml_str = open('operatingreactors.xml', 'r+').read()
xml_dict = xmltodict.parse(xml_str)
items = xml_dict["facilitylocator"]["facility"]

def convert_dict(items):
    return json.dumps(
        {  "type": "FeatureCollection",
            "features": [{
                "type": "Feature",
                "geometry": {
                    "type": "Point",
                    "coordinates": [ float(feature['longitude']), float(feature['latitude']) ]
                },
                "properties": { key: value for key, value in feature.items() if key not in ('latitude', 'longitude') }
                }
               for feature in items
           ]
        }, indent=2, separators=(',', ': ')
    )

with open( 'operatingreactors.json', 'w+') as outfile:
    json.dump(xml_dict, outfile, indent=2, separators=(',', ': '))

with open('operatingreactors.geojson', 'w+') as outfile:
    outfile.write(convert_dict(items))